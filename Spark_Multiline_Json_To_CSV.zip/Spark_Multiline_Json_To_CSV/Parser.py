
import SplitFunction
import SparkConn

SparConObj=SparkConn.SparkEnter.sparkout("spark_job")
df0=SparConObj.read.option("multiline","true").json("<path of your source file>")
SparConObj.udf.register("split_val_reg",SplitFunction.NormalizeJs.split_val)

df0.registerTempTable("raone")
df1=SparConObj.sql("select split_val_reg(dataset.id,dataset.dataset_code,dataset.database_code,dataset.data) as dt_value from raone")

df1.write.csv("<path of your tgt file>",
sep='|',header='true',mode='overwrite',quote='\u0000')







