import os
from pyspark import SparkContext, SparkConf
from pyspark.sql import SQLContext
import SplitFunction
from pyspark.sql import SparkSession
class SparkEnter:

 def sparkout(app_name):
  spark_obj = SparkSession.builder.appName(app_name).config("spark.some.config.option", "some-value").getOrCreate()
  return(spark_obj)






