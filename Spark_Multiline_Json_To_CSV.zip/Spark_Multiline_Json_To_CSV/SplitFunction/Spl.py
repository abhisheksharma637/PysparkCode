class NormalizeJs:
    def __init__(self,inp1,inp2,inp3,inp_list):

        self.inp_cls1=inp1
        self.inp_cls2 = inp2
        self.inp_cls3 = inp3
        self.inp_cls_list = inp_list
        self.str_out= split_val(self.inp_cls1,self.inp_cls2,self.inp_cls3,self.inp_cls_list)

    def split_val(inp1,inp2,inp3,inp):
      l_out = []
      for line in inp:
        l_out.append(str(inp1)+'|'+inp2+'|'+inp3+'|'+line[0]+'|'+line[1]+'\n')
      return "\n".join(l_out)