##############################################################################
This code has 2 packages
SparConn- This package will let you connect to SPARKSESSION and will return spark dataframe object
SplitFunction-This package splits the json fine into normalized structure
#####################################################################################